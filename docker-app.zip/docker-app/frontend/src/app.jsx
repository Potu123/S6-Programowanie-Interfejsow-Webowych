import { useState, useEffect } from 'react'

// Vite udostępnia zmienne z prefiksem VITE_ w kodzie przeglądarki.
// Wartość jest "wbudowywana" w JS podczas `vite build`.
const API = import.meta.env.VITE_API_URL || 'http://localhost:5000'

export default function App() {
  const [todos, setTodos]   = useState([])
  const [input, setInput]   = useState('')
  const [error, setError]   = useState(null)

  const fetchTodos = async () => {
    try {
      const res  = await fetch(`${API}/todos`)
      const data = await res.json()
      if (!res.ok) { setError(data.error); return }
      setError(null)
      setTodos(data)
    } catch {
      setError(`Backend niedostępny pod adresem: ${API}`)
    }
  }

  useEffect(() => { fetchTodos() }, [])

  const addTodo = async (e) => {
    e.preventDefault()
    if (!input.trim()) return
    await fetch(`${API}/todos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: input }),
    })
    setInput('')
    fetchTodos()
  }

  const toggle = (id) => fetch(`${API}/todos/${id}/toggle`, { method: 'PATCH'   }).then(fetchTodos)
  const remove = (id) => fetch(`${API}/todos/${id}`,        { method: 'DELETE'  }).then(fetchTodos)

  return (
    <div style={{ maxWidth: 560, margin: '48px auto', fontFamily: 'system-ui', padding: '0 16px' }}>
      <h1 style={{ marginBottom: 24 }}>📋 TODO App</h1>

      {error && (
        <p style={{ padding: '10px 14px', background: '#fff0f0', border: '1px solid #fcc', borderRadius: 6, color: '#c00', fontFamily: 'monospace' }}>
          ⚠️ {error}
        </p>
      )}

      <form onSubmit={addTodo} style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Nowe zadanie..."
          style={{ flex: 1, padding: '8px 12px', fontSize: 16, border: '1px solid #ddd', borderRadius: 6 }}
        />
        <button
          type="submit"
          style={{ padding: '8px 18px', background: '#0070f3', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 16 }}
        >
          Dodaj
        </button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
        {todos.map((t) => (
          <li key={t.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, marginBottom: 8, background: '#f7f7f7', borderRadius: 8 }}>
            <input type="checkbox" checked={t.done} onChange={() => toggle(t.id)} style={{ width: 18, height: 18, cursor: 'pointer' }} />
            <span style={{ flex: 1, fontSize: 16, textDecoration: t.done ? 'line-through' : 'none', color: t.done ? '#aaa' : '#000' }}>
              {t.title}
            </span>
            <button onClick={() => remove(t.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#c00', fontSize: 20 }}>
              ✕
            </button>
          </li>
        ))}
      </ul>

      {!error && todos.length === 0 && (
        <p style={{ textAlign: 'center', color: '#aaa', marginTop: 32 }}>Brak zadań. Dodaj pierwsze! 🎉</p>
      )}
    </div>
  )
}
