import os
import psycopg2
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # fix na CORSy (inny port = inne "origin")

DB_HOST = os.environ.get("DB_HOST", "localhost")


def get_db():
    """Tworzy nowe połączenie z bazą danych PostgreSQL."""
    return psycopg2.connect(
        host=DB_HOST,
        database=os.environ.get("POSTGRES_DB", "todos"),
        user=os.environ.get("POSTGRES_USER", "postgres"),
        password=os.environ.get("POSTGRES_PASSWORD", "postgres"),
    )


def db_error():
    """Zwraca czytelny błąd 503, gdy baza jest niedostępna."""
    return jsonify({"error": f"Cannot connect to DB: {DB_HOST}"}), 503


# API
@app.route("/todos", methods=["GET"])
def get_todos():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT id, title, done FROM todos ORDER BY id")
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return jsonify([{"id": r[0], "title": r[1], "done": r[2]} for r in rows])
    except Exception:
        return db_error()


@app.route("/todos", methods=["POST"])
def add_todo():
    try:
        data = request.get_json()
        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO todos (title) VALUES (%s) RETURNING id",
            (data["title"],)
        )
        new_id = cur.fetchone()[0]
        conn.commit()
        cur.close()
        conn.close()
        return jsonify({"id": new_id, "title": data["title"], "done": False}), 201
    except Exception:
        return db_error()


@app.route("/todos/<int:todo_id>", methods=["DELETE"])
def delete_todo(todo_id):
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("DELETE FROM todos WHERE id = %s", (todo_id,))
        conn.commit()
        cur.close()
        conn.close()
        return "", 204
    except Exception:
        return db_error()


@app.route("/todos/<int:todo_id>/toggle", methods=["PATCH"])
def toggle_todo(todo_id):
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "UPDATE todos SET done = NOT done WHERE id = %s RETURNING id, title, done",
            (todo_id,)
        )
        row = cur.fetchone()
        conn.commit()
        cur.close()
        conn.close()
        return jsonify({"id": row[0], "title": row[1], "done": row[2]})
    except Exception:
        return db_error()


# ── Start ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
