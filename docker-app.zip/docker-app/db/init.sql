-- Wykonywany automatycznie przy pierwszym starcie kontenera Postgres
-- (inaczej: tylko gdy /var/lib/postgresql/data jest pusty)

CREATE TABLE IF NOT EXISTS todos (
    id    SERIAL  PRIMARY KEY,
    title TEXT    NOT NULL,
    done  BOOLEAN DEFAULT FALSE
);
-- Żeby wykonać ponownie: docker compose down -v i uruchom ponownie
